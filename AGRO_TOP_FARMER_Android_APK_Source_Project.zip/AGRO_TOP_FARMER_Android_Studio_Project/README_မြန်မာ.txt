AGRO TOP FARMER Android App - Source Project

ဤ ZIP သည် Android Studio ဖြင့် APK တည်ဆောက်ရန် source project ဖြစ်ပြီး APK ဖိုင်ကိုယ်တိုင် မဟုတ်ပါ။

APK တည်ဆောက်ရန်:
1. Computer တွင် Android Studio ကို install လုပ်ပါ။
2. Android Studio > Open ကိုနှိပ်ပြီး ဤ ZIP ကို Extract လုပ်ထားသော AGRO_TOP_FARMER_Android_Studio_Project folder ကိုရွေးပါ။
3. Gradle Sync ပြီးဆုံးသည်အထိစောင့်ပါ။
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုရွေးပါ။
5. APK ကို app/build/outputs/apk/debug/app-debug.apk တွင်ရပါမည်။
6. APK ကို Android ဖုန်းသို့ပို့ပြီး ဖွင့်ပါ။ Android က ခွင့်ပြုချက်တောင်းလျှင် ယုံကြည်ရသော source မှ install လုပ်ခြင်းကို ခွင့်ပြုပါ။

အင်္ဂါရပ်:
- Offline WebView app
- Product add/edit/delete/search/filter
- Local data storage
- JSON backup restore
- CSV export
- Print/PDF browser feature (Android WebView support may vary)

သတိ:
- Data သည် ဖုန်းထဲတွင်သာ သိမ်းသည်။
- ဖုန်းနှင့် Computer အကြား အလိုအလျောက် sync မပါဝင်သေးပါ။
- ဖုန်း/Computer နှစ်မျိုးလုံးမှ တစ်ပြိုင်နက်တည်းသုံးရန် cloud backend နှင့် login ထပ်တည်ဆောက်ရန်လိုသည်။
